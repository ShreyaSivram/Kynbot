import sqlite3

conn = sqlite3.connect("user_data.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS user_preferences (
    user_id TEXT,
    interests TEXT,
    location TEXT
)
""")
conn.commit()

def store_user_preferences(user_id, interests, location):
    cursor.execute("INSERT INTO user_preferences (user_id, interests, location) VALUES (?, ?, ?)",
                   (user_id, interests, location))
    conn.commit()

def get_user_preferences(user_id):
    cursor.execute("SELECT * FROM user_preferences WHERE user_id = ?", (user_id,))
    return cursor.fetchone()