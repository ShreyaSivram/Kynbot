import spacy

nlp = spacy.load("en_core_web_sm")

def parse_query(query):
    doc = nlp(query)
    location = None
    keyword = None
    time = None

    for ent in doc.ents:
        if ent.label_ == "GPE":
            location = ent.text
        elif ent.label_ in ["DATE", "TIME"]:
            time = ent.text

    if not keyword:
        keyword = " ".join([chunk.text for chunk in doc.noun_chunks if "event" in chunk.text.lower()])

    return location, keyword, time