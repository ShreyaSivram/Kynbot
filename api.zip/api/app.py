import streamlit as st
from eventbrite_api import search_events
from nlp_utils import parse_query
from geocoding_api import geocode_location
from database import store_user_preferences, get_user_preferences

st.title("Community Discovery Chatbot")

# User Query Input
user_query = st.text_input("Ask me about events:")
user_id = "user123"  # Example user ID, can be dynamic based on authentication

if user_query:
    # NLP Query Parsing
    location, keyword, time = parse_query(user_query)
    
    # Handle Location
    if location:
        coordinates = geocode_location(location)
    else:
        user_prefs = get_user_preferences(user_id)
        coordinates = geocode_location(user_prefs[2]) if user_prefs else None

    # Fetch Events
    if coordinates and keyword:
        events = search_events(location, keyword)
        
        st.subheader("Recommended Events:")
        for event in events.get("events", []):
            st.write(f"**Event:** {event['name']['text']}")
            st.write(f"**Date:** {event['start']['local']}")
            st.write(f"**Location:** {event['venue']['address']['localized_address_display']}")
            st.write("---")

        # Store User Preferences
        store_user_preferences(user_id, keyword, location)
    else:
        st.error("Could not find events. Please refine your query.")