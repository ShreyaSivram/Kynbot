import requests

API_KEY = "Your_Eventbrite_API_Key"
BASE_URL = "https://www.eventbriteapi.com/v3/"

headers = {"Authorization": f"Bearer {API_KEY}"}

def search_events(location, keyword, date_range=None):
    params = {
        "q": keyword,
        "location.address": location,
        "start_date.range_start": date_range[0] if date_range else None,
        "start_date.range_end": date_range[1] if date_range else None,
    }
    response = requests.get(BASE_URL + "events/search/", headers=headers, params=params)
    return response.json()