import requests

def geocode_location(location):
    API_KEY = "Your_Geocoding_API_Key"
    url = f"https://maps.googleapis.com/maps/api/geocode/json?address={location}&key={API_KEY}"
    response = requests.get(url)
    data = response.json()
    if data["results"]:
        lat, lng = data["results"][0]["geometry"]["location"].values()
        return lat, lng
    return None